#ifndef PRODUCCION_H
#define PRODUCCION_H

#define MAX_PRODUCTOS 5
#define MAX_NOMBRE 30

void ingresarProductos(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int *totalIngresados);

void mostrarProductos(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int totalIngresados);
void editarProducto(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int totalIngresados);
void eliminarProducto(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int *totalIngresados);
void calcularOptimizacion(int *cantidades, float *tiempos, float *recursos, int totalIngresados);
#endif