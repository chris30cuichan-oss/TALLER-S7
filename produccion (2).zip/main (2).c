#include <stdio.h>
#include "produccion.h"
#include "validaciones.h"

int main() {
    char nombres[MAX_PRODUCTOS][MAX_NOMBRE];
    int cantidades[MAX_PRODUCTOS] = {0};
    float tiempos[MAX_PRODUCTOS] = {0.0};
    float recursos[MAX_PRODUCTOS] = {0.0};
    
    int totalIngresados = 0;
    int opcion;

    do {
        printf("\n==================================================\n");
        printf("  SISTEMA DE OPTIMIZACIÓN DE PRODUCCIÓN (MÓDULOS)\n");
        printf("==================================================\n");
        printf("1. Ingresar Productos\n");
        printf("2. Mostrar Productos e Inventario\n");
        printf("3. Editar Producto\n");
        printf("4. Eliminar Producto\n");
        printf("5. Calcular Optimización y Viabilidad\n");
        printf("6. Salir\n");
        printf("Seleccione una opción: ");
        opcion = leerEntero();

        switch (opcion) {
            case 1:
                ingresarProductos(nombres, cantidades, tiempos, recursos, &totalIngresados);
                break;
            case 2:
                mostrarProductos(nombres, cantidades, tiempos, recursos, totalIngresados);
                break;
            case 3:
                editarProducto(nombres, cantidades, tiempos, recursos, totalIngresados);
                break;
            case 4:
                eliminarProducto(nombres, cantidades, tiempos, recursos, &totalIngresados);
                break;
            case 5:
                calcularOptimizacion(cantidades, tiempos, recursos, totalIngresados);
                break;
            case 6:
                printf("\nFinalizando el sistema computacional. ¡Éxito en el informe!\n");
                break;
            default:
                printf("\n[ERROR] El número ingresado no está en la lista. Por favor, ingrese un número de la lista (1 al 6).\n");
        }
    } while (opcion != 6);

    return 0;
}