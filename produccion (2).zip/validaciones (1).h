#ifndef VALIDACIONES_H
#define VALIDACIONES_H
void limpiarBuffer();
void leerCadena(char *destino, int longitudMax);
int leerEntero();
float leerFlotante();

#endif