#include <stdio.h>
#include "validaciones.h"

void limpiarBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void leerCadena(char *destino, int longitudMax) {
    int i = 0;
    int c;
    
    while (i < (longitudMax - 1)) {
        c = getchar();
        if (c == '\n' || c == EOF) {
            break;
        }
        *(destino + i) = (char)c;
        i++;
    }
    *(destino + i) = '\0'; 

    if (c != '\n' && c != EOF) {
        limpiarBuffer();
    }
}

int leerEntero() {
    int valor;
    char letraCheck;
    
    while (scanf("%d%c", &valor, &letraCheck) != 2 || letraCheck != '\n') {
        printf("[ERROR] Entrada inválida. Ingrese solo números enteros: ");
        limpiarBuffer();
    }
    return valor;
}

float leerFlotante() {
    float valor;
    char letraCheck;
    
    while (scanf("%f%c", &valor, &letraCheck) != 2 || letraCheck != '\n') {
        printf("[ERROR] Entrada inválida. Ingrese solo números (ej: 12.5): ");
        limpiarBuffer();
    }
    return valor;
}