#include <stdio.h>
#include "produccion.h"
#include "validaciones.h"

void ingresarProductos(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int *totalIngresados) {
    if (*totalIngresados >= MAX_PRODUCTOS) {
        printf("\n[AVISO] Ya se ha alcanzado el límite máximo de %d productos.\n", MAX_PRODUCTOS);
        return;
    }

    printf("\n--- REGISTRO DEL PRODUCTO %d ---\n", *totalIngresados + 1);
    
    printf("Ingrese el nombre del producto: ");
    leerCadena(*(nombres + *totalIngresados), MAX_NOMBRE);

    printf("Ingrese la cantidad demandada: ");
    *(cantidades + *totalIngresados) = leerEntero();
    while (*(cantidades + *totalIngresados) < 0) {
        printf("[ERROR] La cantidad no puede ser negativa. Ingrese de nuevo: ");
        *(cantidades + *totalIngresados) = leerEntero();
    }

    printf("Ingrese el tiempo de fabricación unitario (horas): ");
    *(tiempos + *totalIngresados) = leerFlotante();
    while (*(tiempos + *totalIngresados) <= 0) {
        printf("[ERROR] El tiempo debe ser mayor a cero. Ingrese de nuevo: ");
        *(tiempos + *totalIngresados) = leerFlotante();
    }

    printf("Ingrese los recursos unitarios requeridos: ");
    *(recursos + *totalIngresados) = leerFlotante();
    while (*(recursos + *totalIngresados) <= 0) {
        printf("[ERROR] Los recursos deben ser mayores a cero. Ingrese de nuevo: ");
        *(recursos + *totalIngresados) = leerFlotante();
    }

    (*totalIngresados)++;
    printf("\n[ÉXITO] Producto registrado correctamente.\n");
}

void mostrarProductos(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int totalIngresados) {
    if (totalIngresados == 0) {
        printf("\n[AVISO] No hay productos registrados en el sistema.\n");
        return;
    }

    printf("\n-----------------------------------------------------------------------------\n");
    printf("%-5s | %-20s | %-10s | %-15s | %-15s\n", "ID", "Nombre", "Cantidad", "Tiempo Unit.", "Recurso Unit.");
    printf("-----------------------------------------------------------------------------\n");
    for (int i = 0; i < totalIngresados; i++) {
        printf("%-5d | %-20s | %-10d | %-15.2f | %-15.2f\n", 
               i + 1, *(nombres + i), *(cantidades + i), *(tiempos + i), *(recursos + i));
    }
    printf("-----------------------------------------------------------------------------\n");
}

void editarProducto(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int totalIngresados) {
    if (totalIngresados == 0) {
        printf("\n[AVISO] No hay productos para editar.\n");
        return;
    }

    char buscarNombre[MAX_NOMBRE];
    printf("\nIngrese el nombre exacto del producto que desea EDITAR: ");
    leerCadena(buscarNombre, MAX_NOMBRE);

    int indiceEncontrado = -1;

    for (int i = 0; i < totalIngresados; i++) {
        int j = 0;
        int coinciden = 1;
        
        while (*(*(nombres + i) + j) != '\0' || *(buscarNombre + j) != '\0') {
            if (*(*(nombres + i) + j) != *(buscarNombre + j)) {
                coinciden = 0;
                break;
            }
            j++;
        }
        if (coinciden == 1) {
            indiceEncontrado = i;
            break;
        }
    }

    if (indiceEncontrado == -1) {
        printf("\n[ERROR] Producto no encontrado.\n");
        return;
    }

    printf("\n[Modificando] Guardando datos nuevos para: %s\n", *(nombres + indiceEncontrado));
    
    printf("Nuevo nombre del producto: ");
    leerCadena(*(nombres + indiceEncontrado), MAX_NOMBRE);

    printf("Nueva cantidad demandada: ");
    *(cantidades + indiceEncontrado) = leerEntero();
    while (*(cantidades + indiceEncontrado) < 0) {
        printf("[ERROR] Ingrese una cantidad válida: ");
        *(cantidades + indiceEncontrado) = leerEntero();
    }

    printf("Nuevo tiempo de fabricación unitario: ");
    *(tiempos + indiceEncontrado) = leerFlotante();
    
    printf("Nuevos recursos unitarios requeridos: ");
    *(recursos + indiceEncontrado) = leerFlotante();

    printf("\n[ÉXITO] Producto actualizado de forma correcta.\n");
}

void eliminarProducto(char nombres[][MAX_NOMBRE], int *cantidades, float *tiempos, float *recursos, int *totalIngresados) {
    if (*totalIngresados == 0) {
        printf("\n[AVISO] No hay productos para eliminar.\n");
        return;
    }

    char buscarNombre[MAX_NOMBRE];
    printf("\nIngrese el nombre exacto del producto que desea ELIMINAR: ");
    leerCadena(buscarNombre, MAX_NOMBRE);

    int indiceEncontrado = -1;

    for (int i = 0; i < *totalIngresados; i++) {
        int j = 0;
        int coinciden = 1;
        while (*(*(nombres + i) + j) != '\0' || *(buscarNombre + j) != '\0') {
            if (*(*(nombres + i) + j) != *(buscarNombre + j)) {
                coinciden = 0;
                break;
            }
            j++;
        }
        if (coinciden == 1) {
            indiceEncontrado = i;
            break;
        }
    }

    if (indiceEncontrado == -1) {
        printf("\n[ERROR] Producto no encontrado.\n");
        return;
    }

    for (int i = indiceEncontrado; i < *totalIngresados - 1; i++) {
        int j = 0;
        while (*(*(nombres + i + 1) + j) != '\0') {
            *(*(nombres + i) + j) = *(*(nombres + i + 1) + j);
            j++;
        }
        *(*(nombres + i) + j) = '\0';

        *(cantidades + i) = *(cantidades + i + 1);
        *(tiempos + i) = *(tiempos + i + 1);
        *(recursos + i) = *(recursos + i + 1);
    }

    (*totalIngresados)--;
    printf("\n[ÉXITO] El producto ha sido eliminado del registro.\n");
}

void calcularOptimizacion(int *cantidades, float *tiempos, float *recursos, int totalIngresados) {
    if (totalIngresados == 0) {
        printf("\n[AVISO] Debe registrar productos primero para hacer el análisis.\n");
        return;
    }

    float tiempoTotalRequerido = 0;
    float recursosTotalesRequeridos = 0;

    for (int i = 0; i < totalIngresados; i++) {
        tiempoTotalRequerido += (*(cantidades + i)) * (*(tiempos + i));
        recursosTotalesRequeridos += (*(cantidades + i)) * (*(recursos + i));
    }

    printf("\n--- CONFIGURACIÓN DE RESTRICCIONES DE LA FÁBRICA ---\n");
    printf("Ingrese el tiempo TOTAL de producción disponible (horas): ");
    float tiempoLimite = leerFlotante();
    
    printf("Ingrese la cantidad TOTAL de recursos disponibles: ");
    float recursosLimite = leerFlotante();

    printf("\n==================================================\n");
    printf("             RESULTADOS DEL ANÁLISIS              \n");
    printf("==================================================\n");
    printf("Tiempo Total Necesario:   %.2f horas\n", tiempoTotalRequerido);
    printf("Tiempo Total Disponible:  %.2f horas\n", tiempoLimite);
    printf("Recursos Necesarios:      %.2f unidades\n", recursosTotalesRequeridos);
    printf("Recursos Disponibles:     %.2f unidades\n", recursosLimite);
    printf("--------------------------------------------------\n");

    if (tiempoTotalRequerido <= tiempoLimite && recursosTotalesRequeridos <= recursosLimite) {
        printf("[ESTADO] ¡VIABLE! La fábrica PUEDE cumplir con la demanda proyectada.\n");
    } else {
        printf("[ESTADO] ¡NO VIABLE! Supera las restricciones actuales de la fábrica.\n");
        if (tiempoTotalRequerido > tiempoLimite) {
            printf(" -> Falta tiempo de producción: %.2f horas extras requeridas.\n", (tiempoTotalRequerido - tiempoLimite));
        }
        if (recursosTotalesRequeridos > recursosLimite) {
            printf(" -> Faltan recursos materiales: %.2f unidades faltantes.\n", (recursosTotalesRequeridos - recursosLimite));
        }
    }
    printf("==================================================\n");
}